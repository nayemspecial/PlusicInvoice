import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Billing\BillingController::index
 * @see app/Http/Controllers/Billing/BillingController.php:24
 * @route '/billing'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Billing\BillingController::checkout
 * @see app/Http/Controllers/Billing/BillingController.php:43
 * @route '/billing/checkout/{plan}'
 */
export const checkout = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(args, options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/billing/checkout/{plan}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Billing\BillingController::checkout
 * @see app/Http/Controllers/Billing/BillingController.php:43
 * @route '/billing/checkout/{plan}'
 */
checkout.url = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return checkout.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillingController::checkout
 * @see app/Http/Controllers/Billing/BillingController.php:43
 * @route '/billing/checkout/{plan}'
 */
checkout.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Billing\BillingController::checkout
 * @see app/Http/Controllers/Billing/BillingController.php:43
 * @route '/billing/checkout/{plan}'
 */
    const checkoutForm = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Billing\BillingController::checkout
 * @see app/Http/Controllers/Billing/BillingController.php:43
 * @route '/billing/checkout/{plan}'
 */
        checkoutForm.post = (args: { plan: number | { id: number } } | [plan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkout.url(args, options),
            method: 'post',
        })
    
    checkout.form = checkoutForm
/**
* @see \App\Http\Controllers\Billing\BillingController::portal
 * @see app/Http/Controllers/Billing/BillingController.php:73
 * @route '/billing/portal'
 */
export const portal = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

portal.definition = {
    methods: ["post"],
    url: '/billing/portal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Billing\BillingController::portal
 * @see app/Http/Controllers/Billing/BillingController.php:73
 * @route '/billing/portal'
 */
portal.url = (options?: RouteQueryOptions) => {
    return portal.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillingController::portal
 * @see app/Http/Controllers/Billing/BillingController.php:73
 * @route '/billing/portal'
 */
portal.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: portal.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Billing\BillingController::portal
 * @see app/Http/Controllers/Billing/BillingController.php:73
 * @route '/billing/portal'
 */
    const portalForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: portal.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Billing\BillingController::portal
 * @see app/Http/Controllers/Billing/BillingController.php:73
 * @route '/billing/portal'
 */
        portalForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: portal.url(options),
            method: 'post',
        })
    
    portal.form = portalForm
const billing = {
    index: Object.assign(index, index),
checkout: Object.assign(checkout, checkout),
portal: Object.assign(portal, portal),
}

export default billing