import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import invitations from './invitations'
import members from './members'
/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/team',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
export const invite = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

invite.definition = {
    methods: ["post"],
    url: '/team/invite',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
invite.url = (options?: RouteQueryOptions) => {
    return invite.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
invite.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
    const inviteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invite.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
        inviteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invite.url(options),
            method: 'post',
        })
    
    invite.form = inviteForm
const team = {
    index: Object.assign(index, index),
invite: Object.assign(invite, invite),
invitations: Object.assign(invitations, invitations),
members: Object.assign(members, members),
}

export default team