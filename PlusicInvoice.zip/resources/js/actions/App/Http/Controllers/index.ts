import Billing from './Billing'
import Auth from './Auth'
import Team from './Team'
import Invoices from './Invoices'
import DashboardController from './DashboardController'
import Clients from './Clients'
import Settings from './Settings'
const Controllers = {
    Billing: Object.assign(Billing, Billing),
Auth: Object.assign(Auth, Auth),
Team: Object.assign(Team, Team),
Invoices: Object.assign(Invoices, Invoices),
DashboardController: Object.assign(DashboardController, DashboardController),
Clients: Object.assign(Clients, Clients),
Settings: Object.assign(Settings, Settings),
}

export default Controllers