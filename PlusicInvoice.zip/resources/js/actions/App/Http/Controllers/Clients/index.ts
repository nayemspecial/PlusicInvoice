import ClientController from './ClientController'
const Clients = {
    ClientController: Object.assign(ClientController, ClientController),
}

export default Clients