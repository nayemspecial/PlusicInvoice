import SettingsController from './SettingsController'
const Settings = {
    SettingsController: Object.assign(SettingsController, SettingsController),
}

export default Settings