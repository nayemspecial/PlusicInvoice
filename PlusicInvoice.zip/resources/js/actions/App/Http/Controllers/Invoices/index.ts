import InvoicePublicController from './InvoicePublicController'
import InvoiceController from './InvoiceController'
const Invoices = {
    InvoicePublicController: Object.assign(InvoicePublicController, InvoicePublicController),
InvoiceController: Object.assign(InvoiceController, InvoiceController),
}

export default Invoices