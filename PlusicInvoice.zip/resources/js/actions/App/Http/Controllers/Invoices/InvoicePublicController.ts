import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
export const show = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pay/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
show.url = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'public_token' in args) {
            args = { invoice: args.public_token }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.public_token
                : args.invoice,
                }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
show.get = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
show.head = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
    const showForm = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
        showForm.get = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::show
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:21
 * @route '/pay/{invoice}'
 */
        showForm.head = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
export const pdf = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/pay/{invoice}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
pdf.url = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'public_token' in args) {
            args = { invoice: args.public_token }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.public_token
                : args.invoice,
                }

    return pdf.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
pdf.get = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
pdf.head = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
    const pdfForm = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
        pdfForm.get = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoices\InvoicePublicController::pdf
 * @see app/Http/Controllers/Invoices/InvoicePublicController.php:32
 * @route '/pay/{invoice}/pdf'
 */
        pdfForm.head = (args: { invoice: string | number | { public_token: string | number } } | [invoice: string | number | { public_token: string | number } ] | string | number | { public_token: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
const InvoicePublicController = { show, pdf }

export default InvoicePublicController