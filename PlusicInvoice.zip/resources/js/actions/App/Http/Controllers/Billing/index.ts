import StripeWebhookController from './StripeWebhookController'
import BillingController from './BillingController'
const Billing = {
    StripeWebhookController: Object.assign(StripeWebhookController, StripeWebhookController),
BillingController: Object.assign(BillingController, BillingController),
}

export default Billing