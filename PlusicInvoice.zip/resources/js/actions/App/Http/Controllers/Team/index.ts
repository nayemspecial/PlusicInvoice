import AcceptInvitationController from './AcceptInvitationController'
import TeamController from './TeamController'
const Team = {
    AcceptInvitationController: Object.assign(AcceptInvitationController, AcceptInvitationController),
TeamController: Object.assign(TeamController, TeamController),
}

export default Team