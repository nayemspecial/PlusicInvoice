import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/team',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Team\TeamController::index
 * @see app/Http/Controllers/Team/TeamController.php:26
 * @route '/team'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
export const invite = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

invite.definition = {
    methods: ["post"],
    url: '/team/invite',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
invite.url = (options?: RouteQueryOptions) => {
    return invite.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
invite.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
    const inviteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invite.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::invite
 * @see app/Http/Controllers/Team/TeamController.php:37
 * @route '/team/invite'
 */
        inviteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invite.url(options),
            method: 'post',
        })
    
    invite.form = inviteForm
/**
* @see \App\Http\Controllers\Team\TeamController::revokeInvitation
 * @see app/Http/Controllers/Team/TeamController.php:73
 * @route '/team/invitations/{invitation}'
 */
export const revokeInvitation = (args: { invitation: string | number | { id: string | number } } | [invitation: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: revokeInvitation.url(args, options),
    method: 'delete',
})

revokeInvitation.definition = {
    methods: ["delete"],
    url: '/team/invitations/{invitation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Team\TeamController::revokeInvitation
 * @see app/Http/Controllers/Team/TeamController.php:73
 * @route '/team/invitations/{invitation}'
 */
revokeInvitation.url = (args: { invitation: string | number | { id: string | number } } | [invitation: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invitation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invitation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invitation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invitation: typeof args.invitation === 'object'
                ? args.invitation.id
                : args.invitation,
                }

    return revokeInvitation.definition.url
            .replace('{invitation}', parsedArgs.invitation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::revokeInvitation
 * @see app/Http/Controllers/Team/TeamController.php:73
 * @route '/team/invitations/{invitation}'
 */
revokeInvitation.delete = (args: { invitation: string | number | { id: string | number } } | [invitation: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: revokeInvitation.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::revokeInvitation
 * @see app/Http/Controllers/Team/TeamController.php:73
 * @route '/team/invitations/{invitation}'
 */
    const revokeInvitationForm = (args: { invitation: string | number | { id: string | number } } | [invitation: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: revokeInvitation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::revokeInvitation
 * @see app/Http/Controllers/Team/TeamController.php:73
 * @route '/team/invitations/{invitation}'
 */
        revokeInvitationForm.delete = (args: { invitation: string | number | { id: string | number } } | [invitation: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: revokeInvitation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    revokeInvitation.form = revokeInvitationForm
/**
* @see \App\Http\Controllers\Team\TeamController::updateRole
 * @see app/Http/Controllers/Team/TeamController.php:80
 * @route '/team/members/{user}/role'
 */
export const updateRole = (args: { user: string | number | { id: string | number } } | [user: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateRole.url(args, options),
    method: 'patch',
})

updateRole.definition = {
    methods: ["patch"],
    url: '/team/members/{user}/role',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Team\TeamController::updateRole
 * @see app/Http/Controllers/Team/TeamController.php:80
 * @route '/team/members/{user}/role'
 */
updateRole.url = (args: { user: string | number | { id: string | number } } | [user: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return updateRole.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Team\TeamController::updateRole
 * @see app/Http/Controllers/Team/TeamController.php:80
 * @route '/team/members/{user}/role'
 */
updateRole.patch = (args: { user: string | number | { id: string | number } } | [user: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateRole.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Team\TeamController::updateRole
 * @see app/Http/Controllers/Team/TeamController.php:80
 * @route '/team/members/{user}/role'
 */
    const updateRoleForm = (args: { user: string | number | { id: string | number } } | [user: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Team\TeamController::updateRole
 * @see app/Http/Controllers/Team/TeamController.php:80
 * @route '/team/members/{user}/role'
 */
        updateRoleForm.patch = (args: { user: string | number | { id: string | number } } | [user: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateRole.form = updateRoleForm
const TeamController = { index, invite, revokeInvitation, updateRole }

export default TeamController