<?php

namespace App\Models\Tenants;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $connection = 'tenant';

    protected $fillable = ['key', 'value'];

    public static function get(string $key, mixed $default = null): mixed
    {
        return static::where('key', $key)->value('value') ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => $value]);
    }
}
